
package Agencia;

import java.util.ArrayList;


public class Agencia 
{
    private ArrayList<Nave> listadoNaves;
    
    public Agencia()
    {
        listadoNaves = new ArrayList<>();
    }
    
    
    public void agregarNave(Nave nave) throws NaveRepetidaException
    {
       
        if (listadoNaves.contains(nave))
        {
            throw new NaveRepetidaException("La Nave" + nave.getNombre() + " ya estaba en el listado.");
        }
        listadoNaves.add(nave); 
    
    }
    
    
    public void comandarExploracion()
    {
        for (Nave nave : listadoNaves)
        {
            if (nave instanceof Explorador)
            {
               Explorador explorador = (Explorador) nave;
               explorador.explorar();
            }
            else if (nave instanceof Carguero)
            {
               Carguero carguero = (Carguero) nave;
               carguero.explorar();
            }

        }
    }
    
    
    public void mostrarListadoNaves()
    {
       System.out.println("Listado de Naves:");
        for (Nave nave : listadoNaves) {
            System.out.println(nave.toString()); 
        }
    }
    

    public static void main(String[] args) 
    {
       Agencia agencia = new Agencia();
       
       try {
            // Crear plantas
            agencia.agregarNave(new Explorador("flecha",20,2568,mision.CARTOGRAFIA));
            agencia.agregarNave(new Carguero("evergreen",15,2567,450));
            agencia.agregarNave(new Carguero("flechacargo",30,2570,300));
            agencia.agregarNave(new Crucero("gol",20,2565,786));
            agencia.agregarNave(new Crucero("flechatouring",20,2572,515));
            
            
            
            // Intentar agregar una nave repetida
            agencia.agregarNave(new Crucero("gol",20,2565,786)); // Esto lanzará una excepción
        } catch (NaveRepetidaException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        // Podar las plantas
        agencia.comandarExploracion();

        // Mostrar las plantas
        agencia.mostrarListadoNaves();

       
        
        
        
    }
    
    
    
    
    
    
    
    
}
