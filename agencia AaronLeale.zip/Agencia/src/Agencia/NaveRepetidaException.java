
package Agencia;


public class NaveRepetidaException extends Exception
{
 
    public NaveRepetidaException(String mensaje) 
    {
    super(mensaje);
    }

    
}