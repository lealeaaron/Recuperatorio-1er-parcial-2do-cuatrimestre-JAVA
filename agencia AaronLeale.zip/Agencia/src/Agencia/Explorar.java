package Agencia;


public interface Explorar
{
     boolean explorar();
}
