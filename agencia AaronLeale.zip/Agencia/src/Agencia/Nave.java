package Agencia;


public abstract class Nave {
    protected String nombre;
    protected int tripulacion;
    protected int añoLanzamiento ;

    public Nave(String nombre, int tripulacion, int añoLanzamiento) {
        this.nombre = nombre;
        this.tripulacion = tripulacion;
        this.añoLanzamiento = añoLanzamiento;
    }
    
     public String getNombre() 
        {
        return nombre;
        }
    
    @Override
        public boolean equals(Object obj)
        {
            if(obj == this)
                {
                    return true;
                }
            if(obj == null)
                {
                    return true;
                }
            if(obj instanceof Nave otherNave)
                {
                    return nombre.equals(otherNave.nombre);
                }
            return false;
        }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", tripulacion=" + tripulacion + ", a\u00f1oLanzamiento=" + añoLanzamiento + '}';
    }
    
    
}

