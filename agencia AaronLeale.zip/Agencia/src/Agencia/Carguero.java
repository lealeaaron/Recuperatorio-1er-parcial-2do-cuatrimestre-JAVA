package Agencia;


public class Carguero extends Nave {
    private static final int CARGA_MAX = 500;
    private static final int CARGA_MIN = 100;
    private int carga;
    private boolean explorando; 

    public Carguero(String nombre, int tripulacion, int añoLanzamiento, int carga) 
    {
        super(nombre, tripulacion, añoLanzamiento);
        this.carga = carga;
    }
    
    public String getNombre() 
    {
        return nombre; // Acceso al atributo nombre heredado de Planta
    }

    public boolean explorar()
    {
        if (!explorando) {
            explorando = true;
            System.out.println("La nave " + nombre + " esta explorando.");
            return true;
        } else {
            System.out.println("La nave " + nombre + " ya estaba explorando.");
            return false;
        }         
    }
    
    
    
    @Override
    public String toString() {
        return "Carguero{" + "explorando=" + explorando + '}';
    }
    
    
    
}
