package Agencia;


public class Crucero extends Nave 
{
    private int cantidadPasajeros;

    public Crucero(String nombre, int tripulacion, int añoLanzamiento, int cantidadPasajeros)
    {
        super(nombre, tripulacion, añoLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    public String getNombre() 
    {
        return nombre; // Acceso al atributo nombre heredado de Planta
    }

    @Override
    public String toString() {
        return "Crucero{" + "cantidadPasajeros=" + cantidadPasajeros + '}';
    }
    
}
