package Agencia;


public class Explorador extends Nave{
    
    private boolean explorando; 
    private mision mision;
    
    public Explorador(String nombre, int tripulacion, int añoLanzamiento, mision mision) {
         super(nombre, tripulacion, añoLanzamiento);
         this.mision = mision;
    }

    
    public boolean explorar()
    {
        if (!explorando) {
            explorando = true;
            System.out.println("La nave " + nombre + " esta explorando.");
            return true;
        } else {
            System.out.println("La nave " + nombre + " ya estaba explorando.");
            return false;
        }         
    }
    

    public String getNombre() 
    {
        return nombre; // Acceso al atributo nombre heredado de Planta
    }

    
    @Override
    public String toString() {
        return "Explorador{" + "mision=" + mision + '}';
    }   
    
}
